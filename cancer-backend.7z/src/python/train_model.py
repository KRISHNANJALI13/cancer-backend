import torch
import torch.nn as nn

# Define a simple neural network (Replace with actual sarcoma model)
class SarcomaModel(nn.Module):
    def __init__(self):
        super(SarcomaModel, self).__init__()
        self.fc1 = nn.Linear(256, 128)  # Example input size
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, 1)  # Output layer (e.g., survival prediction)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = torch.sigmoid(self.fc3(x))  # Sigmoid for probability output
        return x

# Initialize and save model
model = SarcomaModel()
torch.save(model, "sarcoma_model.pt")

print("✅ Model saved as sarcoma_model.pt")
