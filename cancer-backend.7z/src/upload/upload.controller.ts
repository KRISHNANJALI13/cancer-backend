import { Controller, Get, Param } from '@nestjs/common';
import { UploadsService } from './upload.service';

@Controller('uploads')
export class UploadsController {
  constructor(private readonly uploadsService: UploadsService) {}

  @Get(':filename')
  async generateReport(@Param('filename') filename: string) {
    const reportData = await this.uploadsService.generateFakeReport(filename);
    return reportData;
  }
}
